from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Post',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=200)),
                ('content', models.TextField()),
                ('published_date', models.DateTimeField(help_text='زمانی که پست باید منتشر (published) شود.')),
                ('counted_view', models.PositiveIntegerField(default=0)),
            ],
            options={
                'ordering': ['-published_date'],
            },
        ),
    ]
